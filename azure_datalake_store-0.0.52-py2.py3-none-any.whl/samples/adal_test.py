import json
import logging
import os
import sys
import adal

def turn_on_logging():
    logging.basicConfig(level=logging.DEBUG)
    #or,
    #handler = logging.StreamHandler()
    #adal.set_logging_options({
    #    'level': 'DEBUG',
    #    'handler': handler
    #})
    #handler.setFormatter(logging.Formatter(logging.BASIC_FORMAT))

# You can override the account information by using a JSON file. Either
# through a command line argument, 'python sample.py parameters.json', or
# specifying in an environment variable of ADAL_SAMPLE_PARAMETERS_FILE.
#
# The information inside such file can be obtained via app registration.
# See https://github.com/AzureAD/azure-activedirectory-library-for-python/wiki/Register-your-application-with-Azure-Active-Directory
#
# {
#   "resource": "your_resource",
#   "tenant" : "rrandallaad1.onmicrosoft.com",
#   "authorityHostUrl" : "https://login.microsoftonline.com",
#   "clientId" : "624ac9bd-4c1c-4687-aec8-b56a8991cfb3",
#   "username" : "user1",
#   "password" : "verySecurePassword"
# }

parameters_file = "params.json"

if parameters_file:
    with open(parameters_file, 'r') as f:
        parameters = f.read()
    sample_parameters = json.loads(parameters)
else:
    raise ValueError('Please provide parameter file with account information.')

authority_url = (sample_parameters['authorityHostUrl'] + '/' +
                 sample_parameters['tenant'])
GRAPH_RESOURCE = '00000002-0000-0000-c000-000000000000'
RESOURCE = sample_parameters.get('resource', GRAPH_RESOURCE)

#uncomment for verbose log
#turn_on_logging()

### Main logic begins
context = adal.AuthenticationContext(
    authority_url, validate_authority=sample_parameters['tenant'] != 'adfs',
    )

token = context.acquire_token_with_username_password(
    RESOURCE,
    sample_parameters['username'],
    sample_parameters['password'],
    sample_parameters['clientId'])

print('Here is the token')
print(json.dumps(token, indent=2))

refresh_token = token['refreshToken']
token = context.acquire_token_with_refresh_token(
    refresh_token,
    sample_parameters['clientId'],
    RESOURCE,
    # client_secret="your_secret"  # This is needed when using Confidential Client,
                                   # otherwise you will encounter an invalid_client error.
    )
### Main logic ends

print('Here is the token acquired from the refreshing token')
print(json.dumps(token, indent=2))